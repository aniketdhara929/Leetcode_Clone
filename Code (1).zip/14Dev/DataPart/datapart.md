Access this sheet for Data:
https://www.notion.so/Project-Data-23f3a78e0e2280ef9a95fb1004e5ecb8?source=copy_link
